void add (int a,int b);
void sub (int a,int b);
void hello(void);
