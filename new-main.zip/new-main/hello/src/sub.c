#include<stdio.h>
void sub(int a,int b)
{
  printf("Subtraction Results =%d\n",a-b);
 }
    
