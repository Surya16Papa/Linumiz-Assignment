#include<stdio.h>
void add(int a,int b)
{
  printf("Addition Results =%d\n",a+b);
 }
    
