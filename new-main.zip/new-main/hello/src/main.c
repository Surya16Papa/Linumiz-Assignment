#include<stdio.h>
#include "calc.h"

int main()
{
 int x=20,y=20;
 hello();
 add(x,y);
 sub(x,y);
 
return 0;
}
 

